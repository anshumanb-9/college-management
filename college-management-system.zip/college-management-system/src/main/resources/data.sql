insert into College(id, name) values(1, 'College 1');
insert into College(id, name) values(2, 'College 2');
insert into College(id, name) values(3, 'College 3');

insert into Department(id, deptname, collegeid) values(1, 'Department 1', 1);
insert into Department(id, deptname, collegeid) values(2, 'Department 2', 2);
insert into Department(id, deptname, collegeid) values(3, 'Department 3',3);

insert into Faculty(id, facultyname, role, departmentid) values(1, 'Faculty 1', 'assistant', 1);
insert into Faculty(id, facultyname, role, departmentid) values(2, 'Faculty 2', 'hod', 2);
insert into Faculty(id, facultyname, role, departmentid) values(3, 'Faculty 3', 'lab-assistant', 3);