package com.example.collegemanagement.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.collegemanagement.models.College;
import com.example.collegemanagement.models.Department;
import com.example.collegemanagement.services.CollegeService;


@RestController
public class CollegeController {

	@Autowired
	private CollegeService collegeService;
		
	@GetMapping("/colleges")//list of college details
	public List<College> getAllLocations() {
		return collegeService.findAll();
	}
		
	@GetMapping("/colleges/{id}")//college detail by id
	public Optional<College> getLocationById(@PathVariable Integer id) {
		return collegeService.findById(id);
	}
	@GetMapping("/colleges/{id}/departments")//departments by college id
	public List<Department> GetDepartmentsByCollege(@PathVariable Integer id) {
	    Optional<College> college = collegeService.findById(id);		
	    if(college.isPresent()) {
		return college.get().getDepartments();
	    }		
	    return null;
	}
	@PostMapping("/colleges/addNew")//adding new college
	public void AddCollege(@RequestBody College college) {
		collegeService.AddCollege(college);
	}
	@PutMapping("/colleges/{id}/update")// update college details
	public void UpdateCollege(@RequestBody College college) {
		collegeService.UpdateCollege(college);
	}
	@PutMapping("/colleges/name/{name}")// update college details by name
	public void UpdateCollegeByName(@RequestBody College college) {
		collegeService.UpdateCollege(college);
	}
	@DeleteMapping("/colleges/{id}/delete")//delete college by id
	public void DeleteCollege(@PathVariable Integer id) {
		collegeService.deleteCollege(id);
	}
	@GetMapping("/colleges/name/{name}")//college details by name
	public Optional<College> getCollegeByName(@PathVariable String name) {
		return collegeService.findByName(name);
	}
}
