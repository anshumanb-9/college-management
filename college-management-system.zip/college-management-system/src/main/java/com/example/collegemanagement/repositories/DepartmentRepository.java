package com.example.collegemanagement.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.collegemanagement.models.Department;

@Repository
public interface DepartmentRepository extends CrudRepository<Department,Integer>{

}
